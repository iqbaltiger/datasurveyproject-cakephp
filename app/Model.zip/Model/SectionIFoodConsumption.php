<?php
App::uses('AppModel', 'Model');
/**
 * SectionIFoodConsumption Model
 *
 */
class SectionIFoodConsumption extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_i_food_consumption';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
