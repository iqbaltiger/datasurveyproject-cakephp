<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB5EthnicCulturalUnitPartTwo Model
 *
 */
class CommunitySectionBB5EthnicCulturalUnitPartTwo extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_b5_ethnic_cultural_unit_part_two';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
