<?php
App::uses('AppModel', 'Model');
/**
 * VillageSectionBFirstPart Model
 *
 */
class VillageSectionBFirstPart extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'village_section_b_first_part';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
