<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB4DemographicSecondPart Model
 *
 */
class CommunitySectionBB4DemographicSecondPart extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
