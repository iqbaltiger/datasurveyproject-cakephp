<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB2Location Model
 *
 */
class CommunitySectionBB2Location extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_b2_location';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
