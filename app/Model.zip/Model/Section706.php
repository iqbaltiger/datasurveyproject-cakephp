<?php
App::uses('AppModel', 'Model');
/**
 * Section706 Model
 *
 */
class Section706 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_706';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
