<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionCPartThree Model
 *
 */
class CommunitySectionCPartThree extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_c_part_three';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
