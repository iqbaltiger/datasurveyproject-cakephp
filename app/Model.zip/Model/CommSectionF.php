<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionF Model
 *
 */
class CommSectionF extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'comm_section_f';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
