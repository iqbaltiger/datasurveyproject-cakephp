<?php
App::uses('AppModel', 'Model');
/**
 * CommunityQuestion702 Model
 *
 */
class CommunityQuestion702 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_question_702';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
