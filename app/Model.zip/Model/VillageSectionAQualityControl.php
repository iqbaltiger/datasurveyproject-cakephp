<?php
App::uses('AppModel', 'Model');
/**
 * VillageSectionAQualityControl Model
 *
 */
class VillageSectionAQualityControl extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
