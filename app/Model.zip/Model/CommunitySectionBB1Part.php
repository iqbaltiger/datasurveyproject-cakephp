<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB1Part Model
 *
 */
class CommunitySectionBB1Part extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
