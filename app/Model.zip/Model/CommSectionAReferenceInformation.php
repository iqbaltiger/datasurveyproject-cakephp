<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionAReferenceInformation Model
 *
 */
class CommSectionAReferenceInformation extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
