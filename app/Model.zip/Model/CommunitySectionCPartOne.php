<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionCPartOne Model
 *
 */
class CommunitySectionCPartOne extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_c_part_one';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
