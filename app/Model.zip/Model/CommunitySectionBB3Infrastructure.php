<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB3Infrastructure Model
 *
 */
class CommunitySectionBB3Infrastructure extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_b3_infrastructure';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
