<?php
App::uses('AppModel', 'Model');
/**
 * VowelSoundSample Model
 *
 */
class VowelSoundSample extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
