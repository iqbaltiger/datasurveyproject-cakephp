<?php
App::uses('AppModel', 'Model');
/**
 * VillageSectionBThirdPart Model
 *
 */
class VillageSectionBThirdPart extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'village_section_b_third_part';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
