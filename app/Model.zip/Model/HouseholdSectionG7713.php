<?php
App::uses('AppModel', 'Model');
/**
 * HouseholdSectionG7713 Model
 *
 */
class HouseholdSectionG7713 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'household_section_g7_713';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
