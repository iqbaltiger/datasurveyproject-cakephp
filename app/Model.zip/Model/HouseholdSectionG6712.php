<?php
App::uses('AppModel', 'Model');
/**
 * HouseholdSectionG6712 Model
 *
 */
class HouseholdSectionG6712 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'household_section_g6_712';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
