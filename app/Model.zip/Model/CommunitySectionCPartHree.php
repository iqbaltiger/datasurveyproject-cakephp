<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionCPartHree Model
 *
 */
class CommunitySectionCPartThree extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_c_part_hree';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
