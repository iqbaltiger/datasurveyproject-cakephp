<?php
App::uses('AppModel', 'Model');
/**
 * TotalProductionCost703G Model
 *
 */
class TotalProductionCost703G extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'total_production_cost_703_g';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
