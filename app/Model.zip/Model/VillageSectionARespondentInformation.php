<?php
App::uses('AppModel', 'Model');
/**
 * VillageSectionARespondentInformation Model
 *
 */
class VillageSectionARespondentInformation extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
