<?php
App::uses('AppModel', 'Model');
/**
 * SocioCulture Model
 *
 */
class SocioCulture extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'socio_culture';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
