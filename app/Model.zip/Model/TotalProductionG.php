<?php
App::uses('AppModel', 'Model');
/**
 * TotalProductionG Model
 *
 */
class TotalProductionG extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'total_production_g';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
