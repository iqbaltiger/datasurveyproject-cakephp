<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionAQualityControl Model
 *
 */
class CommSectionAQualityControl extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
