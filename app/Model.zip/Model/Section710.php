<?php
App::uses('AppModel', 'Model');
/**
 * Section710 Model
 *
 */
class Section710 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_710';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
