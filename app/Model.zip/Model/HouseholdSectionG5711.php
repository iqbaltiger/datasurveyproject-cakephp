<?php
App::uses('AppModel', 'Model');
/**
 * HouseholdSectionG5711 Model
 *
 */
class HouseholdSectionG5711 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'household_section_g5_711';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
