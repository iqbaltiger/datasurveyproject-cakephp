<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionARespondentInformation Model
 *
 */
class CommSectionARespondentInformation extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
