<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionAConstruction Model
 *
 */
class CommSectionAConstruction extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
