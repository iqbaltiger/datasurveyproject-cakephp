<?php
App::uses('AppModel', 'Model');
/**
 * SectionJ Model
 *
 */
class SectionJ extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_j';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
