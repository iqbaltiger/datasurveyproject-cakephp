<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB5EthnicCulturalUnitPartFifth Model
 *
 */
class CommunitySectionBB5EthnicCulturalUnitPartFifth extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_b5_ethnic_cultural_unit_part_fifth';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
