<?php
App::uses('AppModel', 'Model');
/**
 * VillageSectionAReferenceInformation Model
 *
 */
class VillageSectionAReferenceInformation extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
