<?php
App::uses('AppModel', 'Model');
/**
 * Section708 Model
 *
 */
class Section708 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_708';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
