<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB5EthnicCulturalUnitPartThree Model
 *
 */
class CommunitySectionBB5EthnicCulturalUnitPartThree extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_b5_ethnic_cultural_unit_part_three';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
