<?php
App::uses('AppModel', 'Model');
/**
 * CommSectionDDropdown Model
 *
 */
class CommSectionDDropdown extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'comm_section_d_dropdown';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
