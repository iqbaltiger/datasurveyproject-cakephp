<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBB3InfrastructureSecondPart Model
 *
 */
class CommunitySectionBB3InfrastructureSecondPart extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
