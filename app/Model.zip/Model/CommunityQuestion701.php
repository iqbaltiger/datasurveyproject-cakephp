<?php
App::uses('AppModel', 'Model');
/**
 * CommunityQuestion701 Model
 *
 */
class CommunityQuestion701 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_question_701';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
