<?php
App::uses('AppModel', 'Model');
/**
 * Section707 Model
 *
 */
class Section707 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_707';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
