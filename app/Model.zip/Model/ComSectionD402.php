<?php
App::uses('AppModel', 'Model');
/**
 * ComSectionD402 Model
 *
 */
class ComSectionD402 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'com_section_d_402';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
