<?php
App::uses('AppModel', 'Model');
/**
 * CommunitySectionBthirdPart Model
 *
 */
class CommunitySectionBThirdPart extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'community_section_b_third_part';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
