<?php
App::uses('AppModel', 'Model');
/**
 * Section705 Model
 *
 */
class Section705 extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'section_705';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'id';

}
