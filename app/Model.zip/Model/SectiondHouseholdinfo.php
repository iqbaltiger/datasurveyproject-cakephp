<?php
App::uses('AppModel', 'Model');
/**
 * SectiondHouseholdinfo Model
 *
 */
class SectiondHouseholdinfo extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'sectiond_householdinfo';

}
